from arcgis.gis import GIS
from pathlib import Path
import sys

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hcfcd_functions.utility import getValueFromJSON
from hcfcd_tools import TOOL_UpdateMetadataBatch
from hcfcd_constants.values import ROOT_DIR, PORTAL_URL
#######################################################################################################################
## Input Parameters 
username = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="username")
password = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="password")

gis_connection = GIS(PORTAL_URL, username, password)
gdb_directory = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\geodatabases\GDB")
catalog_path = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\tables\DataCatalog_Testing.xlsx")
include_exclude = "Include" ## Values can be either, "Include", "Exclude", or None. If left None everything will be evaluted 
include_exclude_list = ['AirQuality', 'Basemap']  ## The input values must match the Fgdb Name. Leave the .gdb off
#######################################################################################################################

if __name__ == "__main__":
    TOOL_UpdateMetadataBatch.main(gis_conn=gis_connection,
                                gdb_directory=gdb_directory,
                                catalog_path=catalog_path,
                                include_exclude=include_exclude,
                                include_exclude_list=include_exclude_list
                                )