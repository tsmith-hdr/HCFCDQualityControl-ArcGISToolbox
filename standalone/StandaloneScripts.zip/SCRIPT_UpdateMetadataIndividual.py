from arcgis.gis import GIS
from pathlib import Path
import sys
if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hcfcd_functions.utility import getValueFromJSON
from hcfcd_tools import TOOL_UpdateMetadataIndividual
from hcfcd_constants.values import ROOT_DIR, PORTAL_URL
#######################################################################################################################
## Input Parameters 
username = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="username")
password = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="password")

gis_connection = GIS(PORTAL_URL, username, password)
gdb_directory = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB")
catalog_path = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\tables\DataCatalog_Testing_TopTen.xlsx")
item_list = [
    r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB\Economics.gdb\ACS_MedianHouseholdIncome_ByCounty",
    r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB\AirQuality.gdb\AirQualityMaintenance_CO",
    r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB\AirQuality.gdb\EPA_AQI_Monitors"
]
#######################################################################################################################

if __name__ == "__main__":
    TOOL_UpdateMetadataIndividual.main(gis_conn=gis_connection,
                                        gdb_directory=gdb_directory,
                                        catalog_path=catalog_path,
                                        item_list=item_list
                                        )