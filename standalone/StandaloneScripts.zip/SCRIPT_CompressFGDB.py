from pathlib import Path
import sys
import os

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hcfcd_tools import TOOL_CompressFGDB
#######################################################################################################################
## Input Parameters 
item_type = 'File Geodatabase' ## Can be ["File Geodatabase", "Feature Dataset", "Feature Class", "Table"]
items = [r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\ArcGIS\JunkDrawer.gdb"]
#######################################################################################################################

if __name__ == "__main__":

    TOOL_CompressFGDB.main(item_type=item_type,
                           items=items
                          )