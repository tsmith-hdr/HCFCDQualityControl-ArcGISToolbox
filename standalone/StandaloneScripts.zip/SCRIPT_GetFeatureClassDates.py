from pathlib import Path, PurePath
import sys
import os

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hcfcd_tools import TOOL_GetFeatureClassDates
#######################################################################################################################
## Input Parameters 
gdb_list = [r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB\AirQuality.gdb",
            r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Projects\Cascadia\QualityControl\GDB\Basemap.gdb"]  ## Needs to be the full path of FGDB
output_excel = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\outputs\GetDates.xlsx")  ## Full path to the output excel report
time_zone = "America/Denver" ## Can be one of the following ["America/Los_Angeles","America/Denver","America/Chicago","America/New_York"]   
#######################################################################################################################

if __name__ == "__main__":

    TOOL_GetFeatureClassDates.main(gdb_list=gdb_list,
                                   excel_path=output_excel,
                                   timezone=time_zone
                                   )