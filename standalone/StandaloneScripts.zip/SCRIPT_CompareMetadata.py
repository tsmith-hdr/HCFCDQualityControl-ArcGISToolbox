from arcgis.gis import GIS
from pathlib import Path
import sys

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hcfcd_functions.utility import getValueFromJSON
from hcfcd_tools import TOOL_CompareMetadata
from hcfcd_constants.values import ROOT_DIR, PORTAL_URL
#######################################################################################################################
## Input Parameters 
username = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="username")
password = getValueFromJSON(Path(ROOT_DIR, "secrets.json"),key="password")

gis_connection = GIS(PORTAL_URL, username, password)
gdb_directory = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\geodatabases\GDB")
catalog_path = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\tables\DataCatalog_Testing_TopTen.xlsx")
output_excel = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\CascadiaQualityControl-ArcGISToolbox\testing\outputs\CompareMetadata_Entire.xlsx")
text_type = "Plain"  ## Can be either 'HTML' or 'Plain'
spatial_gdb_names = []  ## list of the category specific Geodatabase names that should be evaluated. If left blank all fgdbs will be evaluated
#######################################################################################################################

if __name__ == "__main__":
    TOOL_CompareMetadata.main(gis_conn=gis_connection,
                              gdb_directory=gdb_directory,
                              catalog_path=catalog_path,
                              output_excel=output_excel,
                              text_type=text_type,
                              spatial_gdb_names=spatial_gdb_names
                              )