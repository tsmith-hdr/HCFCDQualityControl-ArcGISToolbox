# Initial Setup
To use the standalone scripts, extract the contents of <i>standalone_.zip</i> to the <i>standalone</i> directory. If the .py files are in any subdirectory, the scripts will not find the associated modules.


# Use 
If you have and ide or text editor (vs code), the scripts can be run using such software. If you do not have access to and ide/text editor, you will need to navigate to the to the .py file in the file explorer, and right-click on the file. In the activated pane select <i>Run with ArcGIS Pro</i> which will launch the script in the terminal.

![image](https://github.com/user-attachments/assets/cecae4d1-6159-4390-b65d-b2bb68a6b67b)


In the terminal, if the tool uses AGOL, you will be prompted to authenticate yourself. This can be done one of two way, either enter your username and password, or use the credentials of the active portal in ArcGIS Pro. 
