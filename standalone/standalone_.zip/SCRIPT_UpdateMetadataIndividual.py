from arcgis.gis import GIS
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.metadatamanagement import TOOL_UpdateMetadataIndividual
from src.constants.paths import PORTAL_URL
#######################################################################################################################
## Input Parameters 
gdb_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb\QC_Test.gdb"
catalog_path = Path(r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\table\Safer Data Catalog.xlsx")
item_list = [str(Path(gdb_path, "BiologicalResources","Streams")),
             str(Path(gdb_path, "ExistingInfrastructure","Bridges"))
             ]
#######################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)

    TOOL_UpdateMetadataIndividual.main(gis_conn=gis_connection,
                                        gdb_path=gdb_path,
                                        catalog_path=catalog_path,
                                        item_list=item_list
                                        )