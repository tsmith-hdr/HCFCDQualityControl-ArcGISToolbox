#################################################################################################################################################################################################################
## Libraries
from pathlib import Path
import os
import sys
import datetime

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.functions import utility
from src.tools.metadatamanagement import TOOL_UpdateServiceMetadataBatch
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR
#######################################################################################################################
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
#################################################################################################################################################################################################################
## Input Parameters 
agol_folders=["SAFER Test"]
item_types=["Feature Service"]
metadata_dict={"licenseInfo":"<i>The Harris County Flood Control District’s Section 203 Safer Feasibility Plan data is offered solely as a convenience to authorized users. It is provided as is and as available and neither HCFCD nor any other person or entity makes any warranty whatsoever regarding it or the information it contains, including but not limited to warranties of accuracy, availability, currency, completeness, non-infringement, or fitness for a particular purpose. By accessing or using it you acknowledge and agree to all of the foregoing.</i>"}
excel_path = os.path.join(OUTPUTS_DIR, "UpdateServiceMetadataBatch", f"UpdateServiceMetadataBatch_{DATETIME_STR}.xlsx")

#################################################################################################################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)
    
    TOOL_UpdateServiceMetadataBatch.main(gis_conn=gis_connection, 
                                         item_types=item_types, 
                                         agol_folders = agol_folders,
                                         metadata_dictionary=metadata_dict, 
                                         output_excel=excel_path)