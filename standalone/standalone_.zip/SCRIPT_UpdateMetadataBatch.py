from arcgis.gis import GIS
from pathlib import Path
import sys

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools import TOOL_UpdateMetadataBatch
from src.constants.paths import  PORTAL_URL
#######################################################################################################################
## Input Parameters 

gdb_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb\QC_Test.gdb"
catalog_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\table\Safer Data Catalog.xlsx"
include_exclude = None ## Values can be either, "Include", "Exclude", or None. If left None everything will be evaluted 
web_app_categories = []  ## The input values must match the Fgdb Name. Leave the .gdb off
#######################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)

    TOOL_UpdateMetadataBatch.main(gis_conn=gis_connection,
                                gdb_path=gdb_path,
                                catalog_path=catalog_path,
                                include_exclude=include_exclude,
                                web_app_categories=web_app_categories
                                )