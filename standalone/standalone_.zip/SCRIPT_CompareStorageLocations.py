#################################################################################################################################################################################################################
## Libraries
from arcgis.gis import GIS
from pathlib import Path
import sys
import datetime

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.datamanagement import TOOL_CompareStorageLocations
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR
#######################################################################################################################
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
#################################################################################################################################################################################################################
## Input Parameters 

gdb_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb\QC_Test.gdb"
catalog_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\table\Safer Data Catalog.xlsx"
excel_path = Path(OUTPUTS_DIR, "CompareStorageLocations",f"CompareStorageLocations_{DATETIME_STR}.xlsx")

#################################################################################################################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)
    
    TOOL_CompareStorageLocations.main(gis_conn=gis_connection,
                                     gdb_path=gdb_path,
                                     catalog_path=catalog_path,
                                     excel_path=excel_path
                                     )