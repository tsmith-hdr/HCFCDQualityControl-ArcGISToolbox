import sys
import datetime 
from pathlib import Path
from arcgis.gis import GIS

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.datamanagement import TOOL_AppendiciesReport
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR
#######################################################################################################################
## Globals
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
#######################################################################################################################
## Input Parameters 
gis_conn=GIS("Pro")
agol_folder_names = ["SAFER Test", "Livermore"]
agol_folders = [gis_conn.content.folders.get(f.replace("'","")) for f in agol_folder_names]
include_records="Overview Only"
include_exclude = "All"
include_exclude_list = None
output_excel =str(Path(OUTPUTS_DIR, "AppendiciesReports", f"AppendiciesReport_{DATETIME_STR}.xlsx"))
#######################################################################################################################

if __name__ == "__main__":

    gis_conn = utility.authenticateAgolConnection(PORTAL_URL)

    TOOL_AppendiciesReport.main(gis_conn=gis_conn,
                                agol_folders=agol_folders,
                                include_exclude_flag=include_exclude,
                                include_exclude_list=include_exclude_list,
                                include_records=include_records,
                                output_excel=output_excel)
