#################################################################################################################################################################################################################
## Libraries
from arcgis.gis import GIS
from pathlib import Path
import sys

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.functions import utility
from src.tools import TOOL_GetFeatureClassDates
from src.constants.paths import OUTPUTS_DIR
from src.constants.values import DATETIME_STR
#################################################################################################################################################################################################################
## Input Parameters 

gdb_path = [r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb\QC_Test.gdb"]
excel_path = Path(OUTPUTS_DIR, "FeatureClassDates",f"FeatureClassDates_{DATETIME_STR}.xlsx")
timezone = "America/Denver"
#################################################################################################################################################################################################################

if __name__ == "__main__":

    
    TOOL_GetFeatureClassDates.main(gdb_list=gdb_path,
                                    excel_path=excel_path,
                                    timezone=timezone
                                     )