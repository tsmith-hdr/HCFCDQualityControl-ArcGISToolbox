import arcpy
from arcgis.gis import GIS
from pathlib import Path
import sys
import os

if str(Path(__file__).resolve().parents[1]) not in sys.path:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools import TOOL_BackupServices
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR
from src.constants.values import DATETIME_STR
#######################################################################################################################
## Input Parameters 

gdb_directory = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb"
spatial_reference = arcpy.SpatialReference(6420)  ## Can be either 'HTML' or 'Plain'
excel_report = os.path.join(OUTPUTS_DIR, "BackupServices", f"BackupServices_{DATETIME_STR}.xlsx")
include_exclude_list = ["Livermore", "Height Zonation- Fortson Pond", "Height Zonation - Illabot Creek", "Height Zonation - Rinker Creek"]  ## list of the category specific Geodatabase names that should be evaluated. If left blank all fgdbs will be evaluated
include_exclude = "Include"
email_from="edward.smith@hdrinc.com"
email_to=["edward.smith@hdrinc.com"]
#######################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)
    
    TOOL_BackupServices.main(gis_conn=gis_connection,
                              gdb_directory=gdb_directory,
                              spatial_reference=spatial_reference,
                              excel_report=excel_report,
                              include_exclude=include_exclude,
                              include_exclude_list=include_exclude_list,
                              email_from=email_from,
                              email_to=email_to
                              )