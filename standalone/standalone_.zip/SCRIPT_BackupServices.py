import os
import sys
import datetime
from pathlib import Path

import arcpy
from arcgis.gis import GIS

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.backupmanagement import TOOL_BackupServices
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR, ROOT_DIR
#######################################################################################################################
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
#######################################################################################################################
## Input Parameters 
gdb_directory = str(Path(ROOT_DIR, "testing","data","gdb"))
spatial_reference = arcpy.SpatialReference(6420) 
excel_report = os.path.join(OUTPUTS_DIR, "BackupServices", f"BackupServices_{DATETIME_STR}.xlsx")
backup_dir = r"\\intranet.hdr\hdr\GIS\West\BOI\MASTER\OTHER_APPS\Python\Test" ## Can't have letter drives
include_exclude_list = ["Livermore", "Height Zonation- Fortson Pond", "Height Zonation - Illabot Creek", "Height Zonation - Rinker Creek"]  ## list of the category specific Geodatabase names that should be evaluated. If left blank all fgdbs will be evaluated
include_exclude = "Include"
email_from="edward.smith@hdrinc.com"
email_to=["edward.smith@hdrinc.com"]
#######################################################################################################################

if __name__ == "__main__":
    if utility.isTaskScheduler():
        username = sys.argv[1]
        if username.lower() == "pro":
            gis_connection = GIS("Pro")
            
        else:
            password = sys.argv[2]
            gis_connection = GIS(PORTAL_URL, username=username, password=password)

    else:
        gis_connection = utility.authenticateAgolConnection(PORTAL_URL)

    TOOL_BackupServices.main(gis_conn=gis_connection,
                              gdb_directory=gdb_directory,
                              spatial_reference=spatial_reference,
                              excel_report=excel_report,
                              backup_dir=backup_dir,
                              include_exclude=include_exclude,
                              include_exclude_list=include_exclude_list,
                              email_from=email_from,
                              email_to=email_to
                              )