import os
import sys
import datetime
import logging
from importlib import reload
from pathlib import Path

import arcpy
from arcgis.gis import GIS

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.backupmanagement import TOOL_BackupServices
from src.constants.paths import  PORTAL_URL, LOG_DIR
from src.constants.values import PROJECT_SPATIAL_REFERENCE
#######################################################################################################################
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
LOG_FILE = os.path.join(LOG_DIR, "Standalone","BackupServices",f"BackupServices_{DATETIME_STR}_Standalone.log")
#######################################################################################################################
## Input Parameters 
backup_dir = r"\\Houcmi-pcs\GISData\City\HCFCD Mapping\SAFER_Study_10367700\7.2_WIP\Data\_Archive\BackupServices" ## Can't have letter drives
agol_folder_names = ["Measures"]
include_exclude_list = ["SAFER Mitigation Measures (HDR 2025)"]#, "Data", "Exisitng Infrastructure", "Future Projects", "H&H", "Half Layers (2025-04-29)", "Hazardous, Toxic, Radioactive Waste (HTRW)", "Measures", "Real Estate"]  ## list of the category specific Geodatabase names that should be evaluated. If left blank all fgdbs will be evaluated
include_exclude = "Include"
email_from="edward.smith@hdrinc.com"
email_to=["edward.smith@hdrinc.com"]
#email_to=["edward.smith@hdrinc.com", "shama.sheth@hdrinc.com"] ## Testing
#email_to = ["shama.sheth@hdrinc.com","edward.smith@hdrinc.com", "robert.graham@hdrinc.com", "stewart.macpherson@hdrinc.com", "aaron.butterer@hdrinc.com"]
#######################################################################################################################
## Logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(LOG_FILE)
fh.setLevel(logging.DEBUG)
# create console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
ch.setFormatter(formatter)
# add the handlers to the logger
logger.addHandler(fh)
logger.addHandler(ch)
#######################################################################################################################
logger.info(f"Run From Standalone")
logger.info(__file__)

if __name__ == "__main__":
    if utility.isTaskScheduler():
        username = sys.argv[1]
        scheduled = True
        if username.lower() == "pro":
            gis_connection = GIS("Pro")
            
        else:
            password = sys.argv[2]
            gis_connection = GIS(PORTAL_URL, username=username, password=password)

    else:
        scheduled=False
        gis_connection = utility.authenticateAgolConnection(PORTAL_URL)

    agol_folders = [gis_connection.content.folders.get(f.replace("'","")) for f in agol_folder_names]

    TOOL_BackupServices.main(gis_conn=gis_connection,
                              spatial_reference=PROJECT_SPATIAL_REFERENCE,
                              agol_folder_objs=agol_folders,
                              backup_dir=backup_dir,
                              include_exclude_flag=include_exclude,
                              scheduled=scheduled,
                              include_exclude_list=include_exclude_list,
                              email_from=email_from,
                              email_to=email_to
                              )