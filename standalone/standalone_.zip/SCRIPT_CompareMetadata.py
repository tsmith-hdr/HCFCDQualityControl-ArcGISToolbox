from arcgis.gis import GIS
from pathlib import Path
import sys
import datetime

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from src.functions import utility
from src.tools.metadatamanagement import TOOL_CompareMetadata
from src.constants.paths import  PORTAL_URL, OUTPUTS_DIR
#######################################################################################################################
DATETIME_STR = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
#######################################################################################################################
## Input Parameters 

gdb_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\gdb\QC_Test.gdb"
catalog_path = r"C:\Users\tedsmith\OneDrive - HDR, Inc\Documents\Python\HCFCDQualityControl-ArcGISToolbox\testing\data\table\Safer Data Catalog.xlsx"
text_type = "Plain"  ## Can be either 'HTML' or 'Plain'
output_excel = Path(OUTPUTS_DIR, "CompareMetadata", f"CompareMetadata_{text_type}_{DATETIME_STR}.xlsx")
web_app_categories = []  ## list of the category specific Geodatabase names that should be evaluated. If left blank all fgdbs will be evaluated
include_exclude = "Include"
#######################################################################################################################

if __name__ == "__main__":
    gis_connection = utility.authenticateAgolConnection(PORTAL_URL)
    
    TOOL_CompareMetadata.main(gis_conn=gis_connection,
                              gdb_path=gdb_path,
                              catalog_path=catalog_path,
                              output_excel=output_excel,
                              text_type=text_type,
                              web_app_categories=web_app_categories,
                              include_exclude=include_exclude
                              )